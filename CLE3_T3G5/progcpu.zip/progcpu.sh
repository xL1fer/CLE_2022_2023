cd progcpu
make clean
make all
./progcpu datSeq1M.bin