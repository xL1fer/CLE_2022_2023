cd prog2
make clean
make all
./prog2 datSeq1M.bin