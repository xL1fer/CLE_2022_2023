cd prog1
make clean
make all
./prog1 datSeq1M.bin